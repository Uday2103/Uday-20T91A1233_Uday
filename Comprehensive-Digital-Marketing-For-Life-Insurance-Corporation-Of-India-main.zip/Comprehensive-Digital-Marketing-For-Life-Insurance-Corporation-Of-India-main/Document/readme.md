Project report in ppt and pdf
